Time Matters Appointment Scheduler

Extract this ZIP. In NetBeans choose File > Open Project and select TimeMatters.
Run the project using demo.Main. JDK 21 or newer is required.
The welcome page is edited in Source; SchedulerFrame has a paired visual form.
Appointments are stored in appointments.tsv in the project working directory.
